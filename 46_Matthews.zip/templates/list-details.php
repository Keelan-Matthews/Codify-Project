<div class="list-details">
    <button class="d-flex text-white align-items-center my-4 fw-bold btn" id="go-back-list-details">
        <i class="fas fa-arrow-left pe-2"></i>
        <p class="mb-0">Go Back</p>
    </button>
    <div class="lighter-gray rounded p-4">
        <h3 class="text-white list-title mb-2"></h3>
        <p class="text-white list-description mb-5"></p>
        <div class="list-events row">
        </div>
    </div>
</div>